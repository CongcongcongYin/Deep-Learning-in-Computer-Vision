maindir = '/Users/caoyupeng/Desktop/EEE408/Lab2Material';
subdir  = dir( maindir );
for i = 1 : length( subdir )
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir)             
        continue;
    end
%     subdirpath = fullfile( maindir, subdir( i ).name, '' );
%     dat = dir( subdirpath );         
%
%     for j = 1 : length( dat )
%         datpath = fullfile( maindir, subdir( i ).name, dat( j ).name);
%         fid = fopen( datpath );
%      
%     end
 
    if((subdir(i).isdir && isequal(subdir(i).name(1:3), 'set')))
        tmp = fullfile(maindir, subdir(i).name);
        ssdir = dir(tmp);
        for j = 1 : length( ssdir )
            if(ssdir(j).isdir)
                if( isequal( ssdir( j ).name, '.' )||...
                    isequal( ssdir( j ).name, '..')||...
                    ~ssdir( j ).isdir)             
                    continue;
                end
                vName1 = fullfile(subdir(i).name, ssdir(j).name);
                fprintf(vName1);
                fnm = [subdir(i).name , ssdir(j).name];
                fprintf(fnm);
                vbb_to_txtt(vName1, fnm);
                fprintf(vName1)
            end
        end
       vName1 = fullfile('set00', subdir(i).name);
         fprintf(vName1);
    end
end
 
function vbb_to_txtt(vName1, fnm)
    % vName = 'set01/V000'
    A = vbb( 'vbbLoad', [dbInfo '/annotations/' vName1] ); 
    path = '/Users/caoyupeng/Desktop/EEE408/Lab2Material/annotations'; 
    %fnm = 'set01-V000.txt';
    c=fopen([path '-' fnm],'w'); 
    for i = 1:A.nFrame 
        iframe = A.objLists(1,i); 
        iframe_data = iframe{1,1}; 
        n1length = length(iframe_data); 
        for  j = 1:n1length 
            iframe_dataj = iframe_data(j); 
            if iframe_dataj.pos(1) ~= 0  %pos  posv 
                fprintf(c,'%d %f %f %f %f\n', i, iframe_dataj.pos(1),iframe_dataj.pos(2),iframe_dataj.pos(3),iframe_dataj.pos(4)); 
            end 
        end 
    end 
    fclose(c); 
end