dirr='/Users/caoyupeng/Desktop/EEE408/Lab2Material/annotations/';

for i=0:10
    if i<=9
%If you want to transfer the data from set10
%Place change the 'set0' to 'set1'

        str1=['set0',num2str(i)];
        temp=fullfile(dirr, str1);
        ssdir=dir(temp);
        for j = 1 : length(ssdir)
            if( ~isequal( ssdir(j).name,'.')&&~isequal( ssdir(j).name,'..'))
                if i==0 && j==3
                    currentframe=0;
                    str2=['V00',num2str(j-3)];
                elseif j<=12
                    currentframe=updateframe;
                    str2=['V00',num2str(j-3)];
                else
                    currentframe=updateframe;
                    str2=['V0',num2str(j-3)];
                end
                vName = ['/Users/caoyupeng/Desktop/EEE408/Lab2Material/annotations/',str1,'/',str2];
                fnm = [str1,str2,'.txt'];
                updateframe=vbb_to_txtt(currentframe,vName, fnm);
            end
        end
    else
        str1=['set',num2str(i)];
        temp=fullfile(dirr, str1);
        ssdir=dir(temp);
        for j = 1 : length(ssdir)
            if( ~isequal( ssdir(j).name,'.')&&~isequal( ssdir(j).name,'..'))
                if j<=12
                    currentframe=updateframe;
                    str2=['V00',num2str(j-3)];
                else
                    currentframe=updateframe;
                    str2=['V0',num2str(j-3)];
                end
                vName = ['/Users/caoyupeng/Desktop/EEE408/Lab2Material/annotations',str1,'/',str2];
                fnm = [str1,str2,'.txt'];
                updateframe=vbb_to_txtt(currentframe,vName, fnm);
            end
            
        end
        
    end
end

function updateframe=vbb_to_txtt(currentframe,vName, fnm)
% vName = 'set01/V000'
A = vbb( 'vbbLoad', vName );
path = '/Users/caoyupeng/Desktop/EEE408/Lab2Material/annotations/';
%fnm = 'set01-V000.txt';
c=fopen([path '-' fnm],'w');
for i = 1:A.nFrame
    iframe = A.objLists(1,i);
    iframe_data = iframe{1,1};
    n1length = length(iframe_data);
    for  j = 1:n1length
        iframe_dataj = iframe_data(j);
        if iframe_dataj.pos(1) ~= 0  %pos  posv
            zero='';
            len=floor(log10(currentframe+i))+1;
            count_zero=6-len;
            while count_zero>0
                zero=[zero,'0'];
                count_zero=count_zero-1;
            end
            str=[zero,num2str(currentframe+i)];
            fprintf(c,[str,' %f %f %f %f\n'],iframe_dataj.pos(1),iframe_dataj.pos(2),iframe_dataj.pos(3),iframe_dataj.pos(4));
        end
    end
end

updateframe=currentframe+A.nFrame;
fclose(c);
end
