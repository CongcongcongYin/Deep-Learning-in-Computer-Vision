%func: main.m  
vbb2txt('V000.vbb','V000.txt');  
%vbb2txt('InriaNewTestLabels.vbb','TestingLabels.txt');  
%[plain] view plain copy
%-------------------------------------------------------  
%vbbName:需要转换的.vbb名称，txtName为转换后保存的.txt名称  
%func: vbb2txt.m  
%-------------------------------------------------------  
